---------------------------------------------
       EFCodeFirst PACKAGE IS OBSOLETE    
---------------------------------------------


A supported go-live version of Code First is now available as part of the 'EntityFramework' package.

The 'EntityFramework' package has been installed to your project. 

Please install 'EntityFramework' directly in the future.